#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>

#include "myprintf.c"

typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned long u32;

char buf[512]; //buffer for reading in contents of vdisk
int fd; //pointer
int sector;
struct partition *p; //partition pointer
struct local_MBR *l; //lobal MBR pointer

struct partition {
  u8 drive;         //0x80 t0 active
  u8 head;          //starting head
  u8 sector;        //starting sector
  u8 cylinder;      //starting cylinder
  u8 sys_type;      //partition type
  u8 end_head;      //end head
  u8 end_cylinder;  //end cylinder
  u32 start_sector; //starting sector counting from 0
  u32 num_sectors;  //number of sectors in partition
} partition;

struct local_MBR {
	u8 boot;             //boot location
	u8 start_sector1;    //starting sector
	u8 sys_type;         //type of system
	u8 end_sector1;      //location of end of sector
  u16 start_sector2;   //start of sector two
	u16 end_sector2;     //end of sector two
	u32 next_addr;       //address of next sector
	u32 size;            //size of sector
} local_MBR;

void print_partition_raw(int n, struct partition *p) //print raw partition
{
	my_printf("part # %4u active %3x s_sect %4u nmbr_sect %4u end %4u\n",
    n, p->drive, p->start_sector, p->num_sectors, p->num_sectors-1);
	my_printf("p_type %4x\n", p->sys_type);
}

unsigned int print_extend_raw(int n, struct local_MBR *l, unsigned int e)
{
	my_printf("part # %4u active %3x s_sect %4u nmbr_sect %4u end %4u\n",
    n, l->boot, e+l->next_addr, l->size, (l->size+e+l->next_addr)-1);
	my_printf("p_type %4x\n", l->sys_type);

	return l->size;
}

int main(int argc, char *argv[ ], char *env[ ])
{
	int i = 0;
  int fd = 0;
  int r = 0;
	unsigned int e, s;

	sector = 0;
	fd = open("vdisk", O_RDONLY);          // open vdisk to read
  lseek(fd, 0, 0);
	r = read(fd, buf, 512);
	p = (struct partition*)&buf[0x1BE];

	for(i = 1; i < 5; i++, p++)
  {
			print_partition_raw(i, p);

			if(p->sys_type == 0x05)
			{
				e = (p->start_sector);
				lseek(fd, (long)e, 0);
				read(fd, buf, 512);

				l = (struct localMBR*)&buf[0x1BE];
        s = 0;
				lseek(fd, ((l->next_addr)+e)*512, 0);
				read(fd, buf, 512);

				l = (struct localMBR*)&buf[0x1BE];
				s = print_extend_raw(++i, l++, e);
				lseek(fd, ((l->next_addr)+e)*512, 0);
				read(fd, buf, 512);

				l = (struct localMBR*)&buf[0x1BE];
				s = print_extend_raw(++i, l++, e+s+18);
				lseek(fd, ((l->next_addr)+e)*512, 0);
				read(fd, buf, 512);

				l = (struct localMBR*)&buf[0x1BE];
				s = print_extend_raw(++i, l, e+s+360+18);
			}
	}
	close(fd);
}
